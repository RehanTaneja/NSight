Files:
 - dt_model.joblib (Decision Tree)
 - rf_model.joblib (Random Forest)
 - xgb_model.json or xgb_model.joblib (XGBoost)
 - keras_model.h5 (Keras/TensorFlow model)
 - scaler.joblib (feature scaler)
 - feature_names.json (ordered list of feature column names expected by the models)

Convert to ONNX locally with the provided convert_to_onnx.py script (see instructions).
